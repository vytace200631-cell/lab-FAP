`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
Yq5A7b694nrk4wsgtq6gY1inhdF1WbfGdtRMtD/P/yf1dL7z36xZi4CcmoX8CUQKA/Ml+1vuql7J
oZGHPVOHp6WodY5gi3+DnOary0q4/Nnp9Lw7SCDkyU1QBi2xo81fjRwZD+wXqSeV2aFvFnGKcoPG
QpGKZdHsJDz5Rq8rBND24G+L/V4UTdRnkrF9W9f0XoQxGznp5v4Njeuuh2mBAdZaUE6O0NIxBmwH
Tb8ViIL+ljUXWMVvYKuiM70rA7ez1YZfLV7kRUeJDANjZvoLBP6OnCrIgyf8Kd7r8qEhHtg59vOv
9NtRpgBxm0VZ4wpMYSerIeWNSXMygD0i8x3RCw==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
YKhUcaqE2OKfCVh08zG5CqFKQI7M1EyeyKLlR/rXXb6bfkpJJtZ+aTWT1ReDy0Y1qBq/Ikwt2F5u
jMuzJRIR9oVIXgN0LmGSc1OeIOl1GUYxqdm1QNCw0htEt7draGtwzOrKE+MJQegPLsl9nlATUFwX
WNlwgxkAIvcYpU8xgCrqaCaJnixmoufExAapBMJMxk5x7T+EZqhPuxu7rQlkeKBN72f9fU7geJfJ
lb9mqPVCr1PHjngWE/6kcUfQRp/Vclmx2lZQFMIQF3E0NmuTHneLbrWwVHtGZMD1Tfp0NGl8UIBk
F45n9LHbM6U8AAZdCjU8AMO6meh5kGfaoqE5ww==
`pragma protect end_protected
