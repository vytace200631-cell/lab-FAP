`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
n43PjG3lptSzqwh6m0UBLGqg4WRSbd09O3RPYsyGkoNC8uGUE2ysx4qEd4H4Lg5WS6EmgGIvqxWQ
J51u07fUe0sgAVB2Nui+Be15HriCB9O+fc3a7CSoleB+gUttofC0U9EMzSfRxS3E9Cyttb6dG+Ig
OBmCKi7kQ2D26h5O+ouiYV+J2/BJD76lR1Dg0XEK/6YEpU1sBQo7DTE+wDyv4D+xv3mF6H0tR7PM
DwlEGEo6ydTF6SQCW1wYr8CO5o1Hy3s+Ytq4DC9OO8oIuYQ3zhbCLcS+fKbHQt5KcN/PCnpqRUJj
l37+YKYhEU2fJWPSFQ8/eXlnrNPEyhM/p0JpFQ==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=624)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
xr3OLBNJHa2FUh6PaEqSZQoe7sMbFEmxJcvECSI9iKvaA8DZ89CBEaE/ec3XrHDXSSNL9vup697b
RiYrun3a+A3XIQiieP6TbHNvwQto6vW5h5Xy39Uk8+EbrG9P2guLCL0kWsgY8aCPWwChwvDhBIV7
lsCByqPNdkzJGWChi4aOHrq0oW1vIgzqAoNXVb2DcQfPLTfjsfS3trqvV8cuDmg+OJYAgDU3kj6p
bhJtibIwHYYGIn8ufoHUyTpITQyVHuIb3eal3TkdwFyuOC2KprDYDKFJhYCziTV/DwUKAs2jLMAz
t0hCVSe72+HqTh2u8MBJWKYnl/dfu/dRSPkgPiJrnWSp4vODTPME/p3N+DalugfqkIjAI2aosANz
6kv0l7+VbX60CJZxNh4DXwM0izm6+0gLUkj5JAEUQqeQNGQwEDpiioD9Yeff4dn2aIuHSDLzSzVE
sqhptrHrwQD3piF6CPaYbq7T3ZjG8C2zB+Fgv28/P1sEPZ+n3F8sAt5VSGQH/4WVZAwSGgMkgzo6
Bsk6TIaMA+4F6q3v6RqubJ20qSnPQGtMEBi9cJ3ANX16w9+ndtZ93IoYTKNIpb5bT4QG6++TFaS1
J/37ru0beCrL3mLNgncsscpZZLy2MWp6y76KDRekuK4oTZ6FKt7jtwpKuDKFjbrYMkeNxihyTh6R
3cluRd1y78pW3/n4wwSFmKPbhkXkFl+Zxqk2rcZd9orkgXoV9pW5wDnRCKWfb3ldXZZNKGNR538f
UZ4pZ42uSaZMRyljbZVA3HWpNNjb14Syl0jziAqsvaOR+w1eIe6bImFYzXIiNU1P9Q4zGq41
`pragma protect end_protected

`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
IMenHxQMuxq0kdRuAqpKiXiB7OMBv9PkVg9khLsFGlsgujd8kC7jlzNYVvLXA7yz00SFOnkPg6oD
NLSLnyakrp9mYAWvlYazZBM4xoPWQQfJ6EdSjos+/PVMagT9jGgJ4oYZPbqDQjEvQ0gUtg1s0wFE
nCLL9kvoUjZDYLR8QkCaKWzxSIxbTybZSacRRj7buYXvZZ/8TPon4AsuGafjTkf3Y4CP3lqgySoI
B/fIQ+X9GbVItLY/aVw3DEeT+SjCayFVltGdUdhNlCYR16C/XbGI8e9dm2auodB5oqLdxT4u3FoK
TNupiYQD1IJDPIZDCnA0esSG08tBsyl+xbEJ8Q==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=1952)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
xr3OLBNJHa2FUh6PaEqSZRUtubTBo01o4LICdR1XMDcC4BS9aoxnDeJBPdB2vccHX4+bZS5jmb1S
grJFQOoP6Fnq8dKO194ZX+82smktGq3sW4DGKzCOhiPMHa04TLdukH8ZJplAUB524BkyILsyKWeq
EbW7AOdFFmD23yl79zZdyt9xiwb+qZPv91IvyJvyKdebR2ih0nz/bQODqAM2DtXBXr2KiRn5ozxA
ZvFop0+1YT3CNkVYFpURztfbJoNcqjPZ1OMPrxN6rcuirboapYQWueJ5qhJzxd1J9qKYnhndRYcO
Nm0Cflpne+ZQHdwl7a9UQDm9VfAuqVJ50fR9tv8MNsBRM4hb4vyVuOj0DBYhfbF7g/h9DElrvIsM
G05z49T9xmTVLUqNXS7bERWk20QrVdFMwFM+P6Q+HUlsYRccmmCK7PZSFnggGwuUUW/KDSxFhsm2
xrBpXaLm6rfUYfNSIQhM6wm8mDmN3GswkIG2lueFpMe2y/rJo4ciTn2BPmsT55OFxw+n/2YUNBMS
h0upan6/AfgVMYAH//MldpgWIdInDYv3hMVMFTHcashVj+tjgNSy7FoZkorKqF0E9HVm4ChCkruV
GGacEKu8Vab17LN/dxUNiA/4lh7/4nAOQytOsmFcPtaVOaMpO6WLViQXgqcfJoMPaJvTOTR4s3Rp
vphOyVSdc9nora09pcGLcqv7qVCHE1xWEHnosK6iQOGQyXgL19pApzmUHyae0U5RgT8e4aNlMYeG
JJdLNuE1/swIy0pt0dIQ+t9jGNC99fkJhO2mASqQzdP5IJuYKU5SJ/968ybTxVn5BY5/hiVYtd3n
fWq+mIAHt2wPNFjbc402Hexp2pI0XktmsHxYx9DUie0dA7UiPZ0cA0h1MpPSN8Tl1v65G9wul4yS
NOfkcGd/zKQl3ssdXRM/mZR0brQODQiQtCvOnf4mZK+Yik9zJr1lb0LYyJLX1M5dUnCSvywWNeHF
F8ziR1HuB0BbUq/etg4uzx0yYbgsNAvyY5+TzBM+PWooROv+FWu8p7p6ITSbp4ThKxRfX1k7DFMh
EBJ80pXYhFi3PVKcKxW2Svkgt6BzClhDbsfrPjhpVf7UQ1/KchSMyNx+0XiycaxZWsWBJ+UVnm+J
9UDZ7mYvfkL83ehOTqK7sJA4Q6vMBf3Kjl7/Hy727xOgm6rE5o7HjDipaQA9BP197mSsv8nEjPG1
lhRJgRWmfvfqGEOWP8pwlTw6UOSfpdwxLZXwcuUHVYRFhzKMQqV933DpC/pCPcWXsuuVsRtiAjfG
ngU0L9yKKQRiXuIcN6h/kk+U1jbpKQ6dsemW4uXm8HKnQ5DAAMbs3IAfwN45exjDoS5j7NeXPA1g
lCJRNvcW5pRl2lQPXH8=0/Nms/hiA+yZzlrmT4gyv18JHP0c7Z5QEf2caFSkNwcYPyTVj+T/EVRN
A+jjaA0U4iOxO01hw6mp3Cp+u1+dh4BWlIhFmeMDQl7TyMfSWhRNbFq/jFpDh88ZV+zwmqXv1CrZ
Gw9RtLA6Sg5VcdRhKBTEO0A2p14D7qS9pEYdmdB73qFYbc1/vnXo35QnxuRjq7rq+XIpbN1y6FtS
HNwcFuVlGscsGquowonp1C85P55soZdelFH/k5MgiMm2sHyaptYb59aYOIPctL3VgkDvkzSqZW/7
GdyOUCUleUFJBGkDdlufDcTEwzQKendD+YlQUzcsEDkWQLaCOPg2vPce8C1YjqyTdtwr4sJA9dua
NXxThd5yLawW41GHNn8KxQJpODpoRmYUCHiUuz1DwveoTbFX6uaZjU2BSv/RyFFuONwWMTXcjZdi
id9bDpBMDfeGKvUI94ayxQR4ePmPlm15WnOBGWTktvws4u7bFtWReSlKq3DIRCmj+vr62EKZvc2v
myIcrvok/8B2hTUKr6f4dVX/M2RD0ptb6syaSSq1P1bxVLq4zzhChOirzaVLSo7CdzExjqfmCNU2
/Oc7UYHDbbi1VK/hjmgFrTI/jMUAoH3HvvXN2d1Giz3VHyv+iLkmxTfo8Z59jmW4rnwrv+lPtYD4
4MG2JyPC5ueBt42XIuhiI2R1CGt2awgqq5i4eSPJ6c8YniLlfA0+MPJqBO97nivm6GBZd6tqrzeM
EEznSE+acmYjXoIh8Nra6W88LuIzEKoo3/FRr1PtYGeiWRGp5cOT6ekP3+FmG1IsTeeDvWuPdveb
K/6nEzNf+iCIvbXn3BVpxYWNPtzoxrAUu5S9CZq26FOjthnNOg+tFz1aNho6YcLoCniyF6lMfvie
7qXT/zDBvNVKBceqK1GfobiLig0/TOdZ9IWJyWyYgSTggeHTHpfEVaXCNcyYSXNECrjTmuENc0NV
mNmQ+bXRDwlOt1RG7uCP7uYr09bLW9GktK4HrQIK/A5uPtlGWB/cNlIWed9ORhrJK995WG8ObZVJ
ZL1LCw+fmwKNvTcvgtsl9jEej0WskRQX+xRSAJh/yJQVcxp53hmkKju/XLJ0SpKg+qCA6fzb8YNO
NnZPi4fFZaLf2yFTmfoAkQKYv2ErGRVcwC+Wam48DkCot6noT0a8Nn2oo2QDYFrEmodGhlCwg+NE
jFL9kVhl/Z5+ebMtYkI3
`pragma protect end_protected

`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
G9oyMHPH3F++hb9fSAVNjR1Q/mbVtFnHv0sk+8ERdMnV0LVbWzb0IMPurs3Nr4agCsG+94CGTeTE
xtprduJKVtibjUDEKKEqZDezrBXtjRtqJEtQh5FXWNgGgjFGj70X7xJYTt0QgfxwABMDdCutCYJS
HMqEqozrNFZzNh/6MYsFdC7lJLdihzTPBF5WQNQHWgWDfn3RrMf7hNSc7ck4sOgWeJmJIboH6g4S
Bq3teMAaTS1ZP7jY8WYKdz7Ea6Jc4OwJNJqY3V09WFjYlxENLYkc9L+dN1QzteFykgQ1tjVPI4Aw
kpTBcyDYWvGEXtfKBT0iMrdNhAhuIWM+rZ0N9A==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=272)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
xr3OLBNJHa2FUh6PaEqSZYPBS6Iib+JjQlE4ihFQRTbB8vU+X2LX44nWDgmDI0RGf1OUm35SGwdR
6muygxKDx54GfT6pNpcZSpmzAwrwGVwUnAVXdZa8ALAER/A1M221PT4bBza68n8ofQPaFPjQYlVf
wuoAJO/G7xh548+G8mu+6hATiBhGIoHW9N9/KcKgdfOiq0yNMGbllfC7+gWVrfijy9Oussto6d7f
VBUdvi8Q7EjAYm2SI9xBd7REBwZ1p4dvlWenYWqupZZO9Ag74L9fxzMkpMMbA7KNrVbVq3gHaV15
aJm0gIz+GQ4RC9O6Irtntwiit3EYrPX+ETxPU5xNHZzNHlDe8Bk3S/hNj7s=
`pragma protect end_protected
