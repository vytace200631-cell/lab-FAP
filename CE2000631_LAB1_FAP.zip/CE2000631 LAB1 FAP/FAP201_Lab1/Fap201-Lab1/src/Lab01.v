module Lab01 (
    input  wire i_sw1,
    input  wire i_sw2,
    input  wire i_sw3,
    output wire o_led1,
    output wire o_led2,
    output wire o_led3
);

    // Yêu cầu: Nhấn nút thì đèn tắt. 
    // Nếu nút nhấn active-high (bấm = 1) và LED active-low (sáng = 0, tắt = 1):
    // Gán trực tiếp đảo giá trị của switch cho LED.
    assign o_led1 = ~i_sw1; // Nh   ấn i_sw1 (1) -> o_led1 = 0 (Tắt)
    assign o_led2 = ~i_sw2; // Nhấn i_sw2 (1) -> o_led2 = 0 (Tắt)
    assign o_led3 = ~i_sw3; // Nhấn i_sw3 (1) -> o_led3 = 0 (Tắt)

endmodule