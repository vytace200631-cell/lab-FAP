`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
UIAGN+D/VZkY52cN5/Fc0QtTKZQizJuqdLOGKqBnr3t7Rzw5clY5PNTE+c6hmlFKBTuzZhWyv5Aa
EQ+33sSvFtBF5kEgB1o4AOnNTi9ZR+/ioTENSrdnWrnDOLsbVVTvBmsGQjwKdDtxj45gtMwQksFa
aQn022jOBEQ/gx7s3BGOB6MGlR0THgJs+uCaovpdwz4FYHZhHUL/RgclIMPojqXnyEF+C1qX1dYv
LXk0uAg3qqK0cTZkpeM7/F5Zt3Qb51OYt2tDzZHu1wDuK9LSGwLHUEf3hRZnRXMven0jOe3Y2o2U
kA8eki2U9TEMKp/X1zmpOGlpG6yfPJvfTUU8RQ==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=544)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
YH8MXmpvWV7wg2Kx8tWrVm9U6wEf3kKPH3VNEGT+d8f5HUD2cSW150yFIRmhh0Kmuf1kIknvGqlg
YIdHFnQzVIWb7ykl+igApeCtlekHsNodq10sX0IDYiOzLfDax2F25R9B6tLNOtnSaTWzgRESqvpd
xVLM24TinZoUBwUkxQnyjN7NjETvs9zldBLALFN7QjnF7nrF+0IukqgVUpR33xyQklbq1cDcEQCA
23FnzhvqNMTRCWlebUBPtcE7UYGo03zLHRANyBxi2QKHCNpeXtsMMk9gCQLUhxFOHGjIXBYXq1xv
YY0yFNGl94RM+A8AZcfLaJ2NDTq3lIK14YYvtypsyTXs1ME+ImbTXzL/rNaLq/FdjYIMttcN3DuX
Ak54Dg6SiNJ3PkYIoNGPVW//dzE14gFy8t8ggtoIjYFsoDVf2jwQzEqXXd3s4A382iHnbYvjU91D
ELR4lYmhjFDiXaYmnHe6RdcweapbW+xtd1ie9nnMius0TbOiRpnKqIHl2gcZwqidPyL3gGKRbYmS
8811sNCgPbaDHBNdE8dxRyjW4RoHTY2rqnixqhj10guQsX3677PwH+6MZv+0d6VTuKT61LKgeWhZ
U5q3UozgHOUTubBxvrWTPAvBBUfOsWQskGi1eBeBi4Ha6cIV/+4Ra6yRZehbOAsj2Io9duyaw7RO
HekYDQrrHaZ8TNEeO+CC/m49aDotrvtbreQCn8a6qg==
`pragma protect end_protected
