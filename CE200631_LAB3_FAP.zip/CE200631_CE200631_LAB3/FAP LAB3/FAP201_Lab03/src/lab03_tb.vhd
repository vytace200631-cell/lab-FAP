library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity lab03_tb is
end entity lab03_tb;

architecture sim of lab03_tb is

  signal clk   : STD_LOGIC := '0';
  signal i_sw  : STD_LOGIC := '0';
  signal o_led : STD_LOGIC;

begin

  -- Clock 20 ns
  clk <= not clk after 10 ns;

  -- DUT: mạch lab03
  DUT: entity work.lab03
    port map (
      clk   => clk,
      i_sw  => i_sw,
      o_led => o_led
    );

  -- Test process
  process
  begin

    -- Test 1: trạng thái ban đầu
    wait for 40 ns;
    assert o_led = '0'
      report "TEST 1 FAILED: LED should start OFF"
      severity error;

    -- Test 2: nhấn và giữ
    i_sw <= '1';
    wait for 40 ns;

    assert o_led = '0'
      report "TEST 2 FAILED: LED changed while switch was held"
      severity error;

    -- Test 3: thả switch -> LED phải ON
    i_sw <= '0';
    wait for 40 ns;

    assert o_led = '1'
      report "TEST 3 FAILED: LED did not toggle ON after release"
      severity error;

    -- Test 4: nhấn và giữ lần 2
    i_sw <= '1';
    wait for 40 ns;

    assert o_led = '1'
      report "TEST 4 FAILED: LED changed while switch was held"
      severity error;

    -- Test 5: thả lần 2 -> LED phải OFF
    i_sw <= '0';
    wait for 40 ns;

    assert o_led = '0'
      report "TEST 5 FAILED: LED did not toggle OFF after release"
      severity error;

    -- Test 6: nhấn/thả nhanh
    i_sw <= '1';
    wait for 20 ns;
    i_sw <= '0';
    wait for 40 ns;

    assert o_led = '1'
      report "TEST 6 FAILED: fast press/release did not toggle LED"
      severity error;

    report "LAB03: ALL SELF-CHECKING TESTS PASSED"
      severity note;

    wait;
  end process;

end architecture sim;