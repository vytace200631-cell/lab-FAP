`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
Mzz0QgWGvxE7pWD+1ScRAa3qTWvZYpAAmAsuVAkegUHFo57Gnmw/vk4dogcE3zaMaF1T/TXtzLNY
f4aLcLdTyugTGWDdS1pCp01a3dUaFolZwQF3Aiyr8EFOSD/IUCemZQTkSGQ6VUKSVSYqwv8jFAtu
c4y+B1XelqEXAlOzTsZOlEnfBaj5SZpAXU4yDDsIrCRDLOarhjYoQSQeuOJuDOQtW7mvTytveILC
8f1ii4Z8GsEsRiQQQpnfkAmYlldfPmsIZQYPGwMcq6qfhZPPzglzTJbm3D/WT5996SyDBvq+X9em
TNhjFUyYp+V49j6qQFrxpghTTMukG5WkVDb1Ig==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=448)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
CSX6sN2bAaMvZKbw1BME1mAZ32WMwfrfUcAJ+n1R/zUQZM8GgasiKTWp7+QMXItXCZowmR5mOU2T
hrmGnHMbDo4UGK9mFimC5TnQAk199BvLKLItv/dQpX47xrTcvgOHF3L7pAZNjOyUkK4ESuhr2Gm5
7+UeMILCw+19knbr8wSKJKvHggb2LXFDu9T5bYaDUbI1FLwhUqtXDy9IsKRfl1/pgZTVswFRI452
o4CJsiuHqjknnqPkRd5jvMjEbmQIeom+YWvSSi6KdSUGEoY/11vO2IywGSld8a3gmUzCPrxOpJfU
L8gU0mYJT31ETQHMavwBptYf+cqzvhJS+OZEbAtgcjWA4a++PQ2LtbCvfFdCpxpgX2gZVi/8VC2g
CfZJ7CCD5oXnKcJKSrlY4BGFZITWosOONzfAsNDdZjw1kcxA13jES2NuD1urMLh8RUZvyz98rd7U
k8r0hMbWbpzQc0DUITq4KVarby1VrMF3hr9ZdV9jQQZ3dvNO16+rfssNZJ1hqUBlrbDB2kErdkST
7ZtLHdMlCmyGunMHaoTWE8imcY5I9KqAv7sduUshXsrSFqU18KBIDfJQXlccN3j82A==
`pragma protect end_protected
