`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
lrxsHIaUZx4+JRFHJZzc9WL/SgmnqmtvOnnBOjWUrPaGw78OKIHHCw7GZX574r/rTda6lf4AMBMN
ZpqrbywKEA07v8zxMzoGelY6VW3lCxyQdE2Zmgdw6kJXRr+FWj8W0859QipI6CLLHSHJPowM0szA
QsXNiX0jLeUTzW1L1iNccQ5voVIPTxFjt4llmjZSeorY9L0+R8quIR7V225+E0r/94Zq+3/MwxGN
4BWwVM9XzFC4rHU5iLn7pMqcxbwjWbwWOu+CBcPnUHzeNbJCco4EnxagIvJIyw/umhGFD/Z/pl42
lP1UJRjzjR37WgFwbBeeOcJg0tSev0/KL76uWQ==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=448)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
Cu79TdAiEEiKNU1n6CqB18bZwM/eoeAvDtFmsLB5huKF2WVDf2utNXU3K3s02Ukk2UdnzWr2j1Co
VO4xWlj6M1YZ9HtlqYSFYy7Uo7be2jB3XwANvNsAl1wXt3i67v+CjPwvUiLZZMVv+0flU2B3j7nm
uYNmkWKUxPPxyuc18gtz3SSvpkfBvwCgMpWAK/KpdMShMjLW0kPXelZx0FTjful6vpxewYSJyYlc
hEeeOX2Ygu0mmQDS3+gDU7AbLbpq/TuX4x/mZ450/DjmNBHPuP9GGQ6GP4/f7pO6EJtGyrOXpy4N
NlxgtUtmpIja3OWgmp/jzbGZg7BUBxtRQOCqvWbO04AtwqaQ7v6xnWb9Hiba41m43gO5oDNfpZRv
4tTY5uaayHNBx5d3C+Wf6ggkMzjEqpSAS41mzBo+9Zafr72lP5RqO87j78TARRtUNz/GzY0dPClh
XrvNpALtedc9KMa6OHuKQTurpTzdisAZh/G9EnPDjAfTS2t1G+qRIBCbkkBxFIxltzPjTCYm+Y6D
s1IkmAVyBD1/pcVccrSGFT/9xWjo/yjXDPD+nsqog56HSQg0M3Jw4c3LaiESkd9vCg==
`pragma protect end_protected
